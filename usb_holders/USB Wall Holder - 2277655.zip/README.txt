USB Wall Holder by Daavviid on Thingiverse: https://www.thingiverse.com/thing:2277655

Summary:
USB holder, for up to 14 USBs sticks, to store them in ease of access.