import StemfieWb_locator
import os
global StemfieWBpath
global StemfieWB_icons_path
StemfieWBpath = os.path.dirname(StemfieWb_locator.__file__)
StemfieWB_icons_path = os.path.join( StemfieWBpath, 'Icons')

#global main_StemfieWB_Icon
#main_StemfieWB_Icon = os.path.join( StemfieWB_icons_path , 'Stemfie_-_Logo_48x48.png')

class StemfieWorkbench (Workbench): 
    MenuText = "STEMFIE"
    ToolTip = "Banco trabajo para Stemfie"
    Icon = ( StemfieWB_icons_path + "/Stemfie_-_Logo_48x48.png")

    def Initialize(self):
        import Stemfie                              # Carga el modulo 'Stemfie.py'

        list = ["Brace_STR_STD_ERR"]                # Lista con comandos
        list.append("Brace_STR_STD_BRD_AZ")
        list.append("Brace_CRN_ERR_ASYM")
        list.append("Brace_STR_STD_BRM")
        list.append("Brace_STR_SLT_BE_SYM_ERR")
        list.append("Brace_STR_SLT_CNT_ERR")
        list.append("Brace_STR_SLT_FL_ERR")
        list.append("Brace_STR_SLT_SE_ERR")
        list.append("Brace_STR_STD_BRD_AY")
        list.append("Brace_STR_STD_BRT_AZ")
        list.append("Brace_STR_STD_BRT_AY")
        list.append("Brace_STR_STD_CR")             # voy añadiendo los siguientes que se van desarrolando
        self.appendToolbar("Stemfie Brace",list)    # crea una barra de herramientas 'Stemfie Brace' con los iconos de los comandos

        list = ["Beam_STR_ESS_BU"]                  # Lista con comandos
        list.append("Beam_STR_BEM")
        list.append("Beam_AGD_ESS_USH_SYM")
        list.append("Beam_STR_BED")
        list.append("Beam_STR_BET")
        list.append("Beam_STR_BXS_ESS_H")
        list.append("Beam_STR_BXS_ESS_C")           # voy añadiendo los siguientes que se van desarrolando
        self.appendToolbar("Stemfie Beam",list)     # crea una barra de herramientas 'Stemfie Beam' con los iconos de los comandos
        
        list = ["Conector_THR_H_BEM_SFT_1W"]                  # Lista con comandos
        self.appendToolbar("Stemfie Conector",list)     # crea una barra de herramientas 'Stemfie Beam' con los iconos de los comandos
        


Gui.addWorkbench(StemfieWorkbench())                # Carga las barras de herramientas que se denominen
