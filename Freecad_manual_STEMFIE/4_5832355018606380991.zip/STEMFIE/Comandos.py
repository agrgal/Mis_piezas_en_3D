# -*- coding: utf-8 -*-



class ListadoPiezas:

    def __init__(self,obj):
        import FreeCAD
        FreeCAD.Console.PrintMessage("Esto se ejecuta")
        return

    def execute(self,obj):
        import FreeCAD
        FreeCAD.Console.PrintMessage("Esto Tambien")
        # List all objects of the document
        doc = FreeCAD.ActiveDocument()
        objs = self.Objects

        for obj in objs:
            a = obj.Name                                             # list the Name  of the object  (not modifiable)
            #b = obj.Label                                            # list the Label of the object  (modifiable)
            try:
                c = obj.Codigo                                    # list the LabeText of the text (modifiable)
                FreeCAD.Console.PrintMessage(str(a) +" - "+  str(c) + "\n") # Displays the Name the Label and the text
            except:
                FreeCAD.Console.PrintMessage(str(a) + "\n") # Displays the Name and the Label of the object


