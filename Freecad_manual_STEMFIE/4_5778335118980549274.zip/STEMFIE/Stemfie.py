import FreeCAD, FreeCADGui
import Part
from FreeCAD import Base

import StemfieWb_locator
import os
global StemfieWBpath
global StemfieWB_icons_path
StemfieWBpath = os.path.dirname(StemfieWb_locator.__file__)
StemfieWB_icons_path = os.path.join( StemfieWBpath, 'Icons')

 
class STR_STD_ERR_Icon:

    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_ERR")
        Piezas.STR_STD_ERR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD ERR_icon.png'), 'MenuText': 'STR STD ERR', 'ToolTip': 'Brace STR ERR'}  

class STR_STD_BRD_AZ_Icon: 

    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_BRD_AZ")
        Piezas.STR_STD_BRD_AZ(myObj)
        myObj.ViewObject.Proxy = 0

        FreeCAD.ActiveDocument.recompute()

    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD BRD AZ_icon.png'), 'MenuText': 'STR STD BRD AZ', 'ToolTip': 'Brace STR STD BRD AZ'} 

class CRN_ERR_ASYM_Icon:

    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","CRN_ERR_ASYM")
        Piezas.CRN_ERR_ASYM(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace CRN ERR ASYM_icon.png'), 'MenuText': 'CRN ERR ASYM', 'ToolTip': 'Brace CRN ERR ASYM'} 
    
class STR_STD_BRM_Icon:

    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_BRM")
        Piezas.STR_STD_BRM(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD BRM_icon.png'), 'MenuText': 'STR STD BRM', 'ToolTip': 'Brace STR STD BRM'} 
    
class STR_SLT_BE_SYM_ERR_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_SLT_BE_SYM_ERR")
        Piezas.STR_SLT_BE_SYM_ERR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR SLT BE SYM ERR_icon.png'), 'MenuText': 'STR SLT BE SYM ERR', 'ToolTip': 'Brace STR SLT BE SYM ERR'} 

class STR_SLT_CNT_ERR_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_SLT_CNT_ERR")
        Piezas.STR_SLT_CNT_ERR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR SLT CNT ERR_icon.png'), 'MenuText': 'STR SLT CNT ERR', 'ToolTip': 'Brace STR SLT CNT ERR'} 
 
class STR_SLT_FL_ERR_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_SLT_FL_ERR")
        Piezas.STR_SLT_FL_ERR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR SLT FL ERR_icon.png'), 'MenuText': 'STR SLT FL ERR', 'ToolTip': 'Brace STR SLT FL ERR'} 
 
class STR_SLT_SE_ERR_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_SLT_SE_ERR")
        Piezas.STR_SLT_SE_ERR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR SLT SE ERR_icon.png'), 'MenuText': 'STR SLT SE ERR', 'ToolTip': 'Brace STR SLT SE ERR'} 
 
class STR_STD_BRD_AY_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_BRD_AY")
        Piezas.STR_STD_BRD_AY(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD BRD AY_icon.png'), 'MenuText': 'STR STD BRD AY', 'ToolTip': 'Brace STR STD BRD AY'} 

class STR_STD_BRT_AZ_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_BRT_AZ")
        Piezas.STR_STD_BRT_AZ(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD BRT AZ_icon.png'), 'MenuText': 'STR STD BRT AZ', 'ToolTip': 'Brace STR STD BRT AZ'} 
 
class STR_STD_BRT_AY_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_BRT_AY")
        Piezas.STR_STD_BRT_AY(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD BRT AY_icon.png'), 'MenuText': 'STR STD BRT AY', 'ToolTip': 'Brace STR STD BRT AY'} 

class STR_STD_CR_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_STD_CR")
        Piezas.STR_STD_CR(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Brace STR STD CR_icon.png'), 'MenuText': 'STR STD CR', 'ToolTip': 'Brace STR STD CR'} 

class STR_ESS_BU_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_ESS_BU")
        Piezas.STR_ESS_BU(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR ESS BU_icon.png'), 'MenuText': 'STR ESS BU', 'ToolTip': 'Beam STR ESS BU'} 

class STR_BEM_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_BEM")
        Piezas.STR_BEM(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR BEM_icon.png'), 'MenuText': 'STR BEM', 'ToolTip': 'Beam STR BEM'} 

class AGD_ESS_USH_SYM_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","AGD_ESS_USH_SYM")
        Piezas.AGD_ESS_USH_SYM(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam AGD ESS USH SYM_icon.png'), 'MenuText': 'AGD ESS USH SYM', 'ToolTip': 'Beam AGD ESS USH SYM'} 

class STR_BED_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_BED")
        Piezas.STR_BED(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR BED_icon.png'), 'MenuText': 'STR BED', 'ToolTip': 'Beam STR_BED'} 

class STR_BET_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_BET")
        Piezas.STR_BET(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR BET_icon.png'), 'MenuText': 'STR BET', 'ToolTip': 'Beam STR_BET'} 

class STR_BXS_ESS_H_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_BXS_ESS_H")
        Piezas.STR_BXS_ESS_H(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR BXS ESS H_icon.png'), 'MenuText': 'STR BXS ESS H', 'ToolTip': 'Beam STR BXS ESS H'} 

class STR_BXS_ESS_C_Icon:
    
    def Activated(self):
        import Piezas
        myObj = FreeCAD.ActiveDocument.addObject("Part::FeaturePython","STR_BXS_ESS_C")
        Piezas.STR_BXS_ESS_C(myObj)
        myObj.ViewObject.Proxy = 0 # this is mandatory unless we code the ViewProvider too
       
        FreeCAD.ActiveDocument.recompute()
   
    def GetResources(self): 
        return {'Pixmap' : (StemfieWB_icons_path +'/Beam STR BXS ESS C_icon.png'), 'MenuText': 'STR BXS ESS C', 'ToolTip': 'Beam STR BXS ESS C'} 


FreeCADGui.addCommand('Brace_STR_STD_ERR', STR_STD_ERR_Icon())
FreeCADGui.addCommand('Brace_STR_STD_BRD_AZ', STR_STD_BRD_AZ_Icon())
FreeCADGui.addCommand('Brace_CRN_ERR_ASYM', CRN_ERR_ASYM_Icon())
FreeCADGui.addCommand('Brace_STR_STD_BRM', STR_STD_BRM_Icon())
FreeCADGui.addCommand('Brace_STR_SLT_BE_SYM_ERR', STR_SLT_BE_SYM_ERR_Icon())
FreeCADGui.addCommand('Brace_STR_SLT_CNT_ERR', STR_SLT_CNT_ERR_Icon())
FreeCADGui.addCommand('Brace_STR_SLT_FL_ERR', STR_SLT_FL_ERR_Icon())
FreeCADGui.addCommand('Brace_STR_STD_BRD_AY', STR_STD_BRD_AY_Icon())
FreeCADGui.addCommand('Brace_STR_STD_BRT_AZ', STR_STD_BRT_AZ_Icon())
FreeCADGui.addCommand('Brace_STR_STD_BRT_AY', STR_STD_BRT_AY_Icon())
FreeCADGui.addCommand('Brace_STR_STD_CR', STR_STD_CR_Icon())

FreeCADGui.addCommand('Beam_STR_ESS_BU', STR_ESS_BU_Icon())
FreeCADGui.addCommand('Beam_STR_BEM', STR_BEM_Icon())
FreeCADGui.addCommand('Beam_AGD_ESS_USH_SYM', AGD_ESS_USH_SYM_Icon())
FreeCADGui.addCommand('Beam_STR_BED', STR_BED_Icon())
FreeCADGui.addCommand('Beam_STR_BET', STR_BET_Icon())
FreeCADGui.addCommand('Beam_STR_BXS_ESS_H', STR_BXS_ESS_H_Icon())
FreeCADGui.addCommand('Beam_STR_BXS_ESS_C', STR_BXS_ESS_C_Icon())

Icon = os.path.join( StemfieWB_icons_path ,'Stemfie_-_Logo_48x48.png')
