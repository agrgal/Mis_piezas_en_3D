#####################################################################################
#         -------------    Piezas.py   ---------------------------
#  Este codigo contiene la geometria y propiedades de las piezas de Stemfie
#
#  Realizado por: Ander González
#####################################################################################

# Simples
class STR_STD_ERR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros","Valores Pieza","Número Agujeros Pieza Simple\nMínimo = 1")
        #obj.Label = "Nº Agujeros"
        obj.Numero_Agujeros = 2

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros mayor de 1
        if (obj.Numero_Agujeros < 1):
            obj.Numero_Agujeros = 1
            #return
        # El caso de 1 agujero seria una arandela y no tendria rectas
        elif (obj.Numero_Agujeros == 1):
            P = Part.makeCylinder(6.25, 3.5, FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 0, 1))
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector(0, 0, -1), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        # 
        else:
            # Numero de agujeros mayor de 1
            #  ---- Genero puntos de los contornos
            P1 = FreeCAD.Vector(0,-6.25,0)
            P2 = FreeCAD.Vector((obj.Numero_Agujeros-1)*12.5,-6.25,0)
            P3 = FreeCAD.Vector((obj.Numero_Agujeros-1)*12.5,6.25,0)
            P4 = FreeCAD.Vector(0,6.25,0)
            #  ---- Genero puntos para circulos
            PC2 = FreeCAD.Vector(((obj.Numero_Agujeros-1)*12.5)+6.25,0,0)
            PC4 = FreeCAD.Vector(-6.25,0,0)
            #  ---- Creamos lineas y arcos
            L1 = Part.LineSegment(P1,P2) 
            C2 = Part.Arc(P2,PC2,P3)   
            L3 = Part.LineSegment(P3,P4)
            C4 = Part.Arc(P4,PC4,P1)
            #  ---- Creo el contorno
            #W = Part.Wire([L1,C2,L3,C4])

            S = Part.Shape([L1,C2,L3,C4])
            W = Part.Wire(S.Edges)
            
            #  ---- Creo la cara con el contorno
            F = Part.Face(W)
            #  ---- Le doy Volumen a la cara
            P = F.extrude (FreeCAD.Vector(0,0,3.25))
            #  ---- Bucle para agujeros
            for x in range(obj.Numero_Agujeros):
                Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
                P = P.cut (Agujero)
        
        #Part.show(P)
        P.Placement = obj.Placement
        obj.Shape = P

class STR_STD_BRD_AZ:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_X","Valores Pieza","Número Agujeros en X\nMínimo = 2")
        obj.Numero_Agujeros_X=3
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_Y","Valores Pieza","Número Agujeros en Y\nMínimo = 2")
        obj.Numero_Agujeros_Y=2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 60\nMáximo = 180")
        obj.Angulo=60

    def execute(self,obj):
        import Part,FreeCAD,FreeCADGui

        # Compruebo que Numero_Agujeros mayor de 2 y Angulo en 60 y 180
        if (obj.Numero_Agujeros_X < 2) or (obj.Numero_Agujeros_Y < 2) or (obj.Angulo < 60) or (obj.Angulo > 180):
            if (obj.Numero_Agujeros_X < 2) : obj.Numero_Agujeros_X = 2
            if (obj.Numero_Agujeros_Y < 2) : obj.Numero_Agujeros_Y = 2
            if (obj.Angulo < 60) : obj.Angulo = 60
            if (obj.Angulo > 180) : obj.Angulo = 180
            #return
        
        # Genero Pieza en X
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PX = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.Numero_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PX = PX.cut (Agujero)
        # Genero Pieza en Y
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_Y-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_Y-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_Y-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.Numero_Agujeros_Y):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector(x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY = PY.cut (Agujero)

        PY.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)

        P = PX.fuse (PY)
    
        P.Placement = obj.Placement
        obj.Shape = P

class CRN_ERR_ASYM:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_X","Valores Pieza","Número Agujeros en X\nMínimo = 2")
        obj.Numero_Agujeros_X=3
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_Y","Valores Pieza","Número Agujeros en Y\nMínimo = 2")
        obj.Numero_Agujeros_Y=2

    def execute(self,obj):
        import Part,FreeCAD,FreeCADGui

        # Compruebo que Numero_Agujeros mayor de 2
        if (obj.Numero_Agujeros_X < 2) or (obj.Numero_Agujeros_Y < 2):
            if (obj.Numero_Agujeros_X < 2) : obj.Numero_Agujeros_X = 2
            if (obj.Numero_Agujeros_Y < 2) : obj.Numero_Agujeros_Y = 2
            #return
        
        # Genero Pieza en X
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PX = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.Numero_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PX = PX.cut (Agujero)
        # Genero Pieza en Y
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_Y-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_Y-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_Y-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.Numero_Agujeros_Y):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY = PY.cut (Agujero)

        PY.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),90)

        #Pf.append(PX.Shape)
        #Pf.append(PY.Shape)

        P = PX.fuse (PY)
        #P = shape.removeSplitter(P)
        #P = Part.makeCompound(Pf.Shape)

        P.Placement = obj.Placement
        obj.Shape = P
        
class STR_STD_BRM:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_X","Valores Pieza","Número Agujeros en X\nMínimo = 2")
        obj.Numero_Agujeros_X=4
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_Y","Valores Pieza","Número Agujeros en Y\nMínimo = 2")
        obj.Numero_Agujeros_Y=3

    def execute(self,obj):
        import Part,FreeCAD
        import math

        # Compruebo que Numero_Agujeros mayor de 1
        if (obj.Numero_Agujeros_X < 2) or (obj.Numero_Agujeros_Y < 2):
            if (obj.Numero_Agujeros_X < 2) : obj.Numero_Agujeros_X = 2
            if (obj.Numero_Agujeros_Y < 2) : obj.Numero_Agujeros_Y = 2
            #return
        # 
        else:
            # Numero de agujeros mayor de 2
            #  ---- Genero puntos de los contornos
            Pto1 = FreeCAD.Vector(0,-6.25,0)
            Pto2 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,-6.25,0)

            Pto3 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+6.25,0,0)
            Pto4 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+6.25,(obj.Numero_Agujeros_Y-1)*12.5,0)

            Pto5 = FreeCAD.Vector((obj.Numero_Agujeros_X-1)*12.5,((obj.Numero_Agujeros_Y-1)*12.5)+6.25,0)
            Pto6 = FreeCAD.Vector(0,((obj.Numero_Agujeros_Y-1)*12.5)+6.25,0)

            Pto7 = FreeCAD.Vector(-6.25,((obj.Numero_Agujeros_Y-1)*12.5),0)
            Pto8 = FreeCAD.Vector(-6.25,0,0)
            #  ---- Genero puntos para circulos
            PtoC1 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+(math.sin(0.7854)*6.25),math.sin(0.7854)*-6.25,0)
            PtoC2 = FreeCAD.Vector(((obj.Numero_Agujeros_X-1)*12.5)+(math.sin(0.7854)*6.25),((obj.Numero_Agujeros_Y-1)*12.5)+(math.sin(0.7854)*6.25),0)
            PtoC3 = FreeCAD.Vector((math.sin(0.7854)*6.25)*-1,((obj.Numero_Agujeros_Y-1)*12.5)+(math.sin(0.7854)*6.25),0)
            PtoC4 = FreeCAD.Vector((math.sin(0.7854)*6.25)*-1,(math.sin(0.7854)*6.25)*-1,0) 
            #  ---- Creamos lineas y arcos
            L1 = Part.LineSegment(Pto1,Pto2) 
            C1 = Part.Arc(Pto2,PtoC1,Pto3)   
            L2 = Part.LineSegment(Pto3,Pto4)
            C2 = Part.Arc(Pto4,PtoC2,Pto5)
            L3 = Part.LineSegment(Pto5,Pto6)
            C3 = Part.Arc(Pto6,PtoC3,Pto7)
            L4 = Part.LineSegment(Pto7,Pto8)
            C4 = Part.Arc(Pto8,PtoC4,Pto1)
            #  ---- Creo el contorno
            #W = Part.Wire([L1,C2,L3,C4])

            S = Part.Shape([L1,C1,L2,C2,L3,C3,L4,C4])
            W = Part.Wire(S.Edges)
            
            #  ---- Creo la cara con el contorno
            F = Part.Face(W)
            #  ---- Le doy Volumen a la cara
            P = F.extrude (FreeCAD.Vector(0,0,3.25))
            #  ---- Bucle para agujeros
            for x in range(obj.Numero_Agujeros_X):
                for y in range(obj.Numero_Agujeros_Y):
                    Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, y*12.5, -1), FreeCAD.Vector(0, 0, 1))
                    P = P.cut (Agujero)  
        #Part.show(P)
        P.Placement = obj.Placement
        obj.Shape = P

class STR_SLT_BE_SYM_ERR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_T","Valores Pieza","Número Agujeros Total\nMínimo 5")
        obj.Numero_Agujeros_T = 5
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_R","Valores Pieza","Número Agujeros Rasgados\nIgual en ambos lados\nMínimo 2")
        obj.Numero_Agujeros_R = 2

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros_T y Numero_Agujeros_R
        if (obj.Numero_Agujeros_T < 5) or (obj.Numero_Agujeros_R < 2): # Si alguno es menor no modificar pieza
            if (obj.Numero_Agujeros_T < 5) :            # si Numero Total de Agujeros es menor 5 
                obj.Numero_Agujeros_T = 5               # dejarlo en 5
            else:                                       # si no
                obj.Numero_Agujeros_R = 2               # dejar Numero Agujeros del coliso en 2
            #return
        if (obj.Numero_Agujeros_R*2)+1 > (obj.Numero_Agujeros_T):
            obj.Numero_Agujeros_T = (obj.Numero_Agujeros_R*2)+1
        # ----------------------------
        #  ---- Genero Cuerpo exterior
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_T-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_T-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_T-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  -----------------------------
        #  ---- Genero Cuerpos a restar 
        #  -----------------------------
        #  ---- Genero Cuerpos a restar de los dos extremos
        for x in range (2):
            if x == 0 :
                Desp = 0
            else:
                Desp = (((obj.Numero_Agujeros_T-(obj.Numero_Agujeros_R*2)) + obj.Numero_Agujeros_R))*12.5

            Pto01 = FreeCAD.Vector(0+Desp,-3.5,0)
            Pto02 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,-3.5,0)
            Pto03 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,3.5,0)
            Pto04 = FreeCAD.Vector(0+Desp,3.5,0)
            #  ---- Genero puntos para circulos
            PtoC2 = FreeCAD.Vector((((obj.Numero_Agujeros_R-1)*12.5)+3.5)+Desp,0,0)
            PtoC4 = FreeCAD.Vector(-3.5+Desp,0,0)
            #  ---- Creamos lineas y arcos
            LRest1 = Part.LineSegment(Pto01,Pto02) 
            CRest2 = Part.Arc(Pto02,PtoC2,Pto03)   
            LRest3 = Part.LineSegment(Pto03,Pto04)
            CRest4 = Part.Arc(Pto04,PtoC4,Pto01)
            SRest = Part.Shape([LRest1,CRest2,LRest3,CRest4])
            WRest = Part.Wire(SRest.Edges)
            #  ---- Creo la cara con el contorno
            FRest = Part.Face(WRest)
            PRest = FRest.extrude (FreeCAD.Vector(0,0,5))
            P = P.cut (PRest)

        #  ---- Bucle para agujeros
        for x in range(obj.Numero_Agujeros_T-(obj.Numero_Agujeros_R*2)):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector((obj.Numero_Agujeros_R + x)*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)

        P.Placement = obj.Placement
        obj.Shape = P

class STR_SLT_CNT_ERR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_T","Valores Pieza","Número Agujeros Total\nMínimo 4")
        obj.Numero_Agujeros_T = 4
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_R","Valores Pieza","Número Agujeros Rasgados\nMínimo 2")
        obj.Numero_Agujeros_R = 2

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros_T y Numero_Agujeros_R
        if (obj.Numero_Agujeros_T < 4) or (obj.Numero_Agujeros_R < 2): # Si alguno es menor no modificar pieza
            if (obj.Numero_Agujeros_T < 4) :            # si Numero Total de Agujeros es menor 4
                obj.Numero_Agujeros_T = 4               # dejarlo en 4
            else:                                       # si no
                obj.Numero_Agujeros_R = 2               # dejar Numero Agujeros del coliso en 2
            #return
        # Ahora compuebo que la longitud total no sea menor de lo necesario 
        if ((obj.Numero_Agujeros_T-obj.Numero_Agujeros_R)%2) != 0 :
            obj.Numero_Agujeros_T = (obj.Numero_Agujeros_T)+1
        # ----------------------------
        #  ---- Genero Cuerpo exterior
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros_T-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros_T-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros_T-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  -----------------------------
        #  ---- Genero Cuerpos a restar 
        #  -----------------------------
        #  ---- Genero cilindros a restar de los dos extremos
        for x in range (2):
            if x == 0 :
                Desp = 0
            else:
                Desp = ( ( (obj.Numero_Agujeros_T - obj.Numero_Agujeros_R) / 2 ) + obj.Numero_Agujeros_R )*12.5
            #  ----  agujeros
            for y in range ( int( ( obj.Numero_Agujeros_T - obj.Numero_Agujeros_R ) / 2 ) ) :
                Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector((y*12.5)+Desp, 0, -1), FreeCAD.Vector(0, 0, 1))
                P = P.cut (Agujero)

        # Genero la forma central
        Desp = ((obj.Numero_Agujeros_T-obj.Numero_Agujeros_R)/2)*12.5       

        Pto01 = FreeCAD.Vector(0+Desp,-3.5,-1)
        Pto02 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,-3.5,-1)
        Pto03 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,3.5,-1)
        Pto04 = FreeCAD.Vector(0+Desp,3.5,-1)
        #  ---- Genero puntos para circulos
        PtoC2 = FreeCAD.Vector((((obj.Numero_Agujeros_R-1)*12.5)+3.5)+Desp,0,-1)
        PtoC4 = FreeCAD.Vector(-3.5+Desp,0,-1)
        #  ---- Creamos lineas y arcos
        LRest1 = Part.LineSegment(Pto01,Pto02) 
        CRest2 = Part.Arc(Pto02,PtoC2,Pto03)   
        LRest3 = Part.LineSegment(Pto03,Pto04)
        CRest4 = Part.Arc(Pto04,PtoC4,Pto01)
        SRest = Part.Shape([LRest1,CRest2,LRest3,CRest4])
        WRest = Part.Wire(SRest.Edges)
        #  ---- Creo la cara con el contorno
        FRest = Part.Face(WRest)
        PRest = FRest.extrude (FreeCAD.Vector(0,0,5))   # Extruyo 5
        P = P.cut (PRest)


        P.Placement = obj.Placement
        obj.Shape = P

class STR_SLT_FL_ERR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","Numero_Agujeros","Valores Pieza","Número Agujeros\nMínimo 2")
        obj.Numero_Agujeros = 2
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros
        if (obj.Numero_Agujeros < 2): # Si es menor no modificar pieza
            obj.Numero_Agujeros = 2               # dejar Numero Agujeros en 2
            #return
        # ----------------------------
        #  ---- Genero Cuerpo exterior
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.Numero_Agujeros-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.Numero_Agujeros-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.Numero_Agujeros-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,3.25))
        
        #  ---- Genero el Cuerpo Interior a restar 
        #  -----------------------------
        
        Pto01 = FreeCAD.Vector(0,-3.5,-1)
        Pto02 = FreeCAD.Vector(((obj.Numero_Agujeros-1)*12.5),-3.5,-1)
        Pto03 = FreeCAD.Vector(((obj.Numero_Agujeros-1)*12.5),3.5,-1)
        Pto04 = FreeCAD.Vector(0,3.5,-1)
        #  ---- Genero puntos para circulos
        PtoC2 = FreeCAD.Vector((((obj.Numero_Agujeros-1)*12.5)+3.5),0,-1)
        PtoC4 = FreeCAD.Vector(-3.5,0,-1)
        #  ---- Creamos lineas y arcos
        LRest1 = Part.LineSegment(Pto01,Pto02) 
        CRest2 = Part.Arc(Pto02,PtoC2,Pto03)   
        LRest3 = Part.LineSegment(Pto03,Pto04)
        CRest4 = Part.Arc(Pto04,PtoC4,Pto01)
        SRest = Part.Shape([LRest1,CRest2,LRest3,CRest4])
        WRest = Part.Wire(SRest.Edges)
        #  ---- Creo la cara con el contorno
        FRest = Part.Face(WRest)
        PRest = FRest.extrude (FreeCAD.Vector(0,0,5))   # Extruyo 5
        P = P.cut (PRest)                               # Resto

        P.Placement = obj.Placement
        obj.Shape = P

class STR_SLT_SE_ERR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros","Valores Pieza","Nº Agujeros Sueltos\nMínimo 1")
        obj.N_Agujeros = 1
        obj.addProperty("App::PropertyInteger","Numero_Agujeros_R","Valores Pieza","Número Agujeros Rasgados\nIgual en ambos lados\nMínimo 2")
        obj.Numero_Agujeros_R = 2
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que N_Agujeros y Numero_Agujeros_R
        if (obj.N_Agujeros < 1) or (obj.Numero_Agujeros_R < 2): # Si alguno es menor de lo permitido
            if (obj.N_Agujeros < 1) :                           # si Numero de Agujeros es menor 1
                obj.N_Agujeros = 1                              # dejarlo en 1
            else:                                               # si no a cambiado N_Agujeros, a sido Numero_Agujeros_R
                obj.Numero_Agujeros_R = 2                       # dejar Numero Agujeros del coliso en 2
            #return
        
        # Creo la variable de total agujeros 
        Numero_Agujeros_T = obj.N_Agujeros + obj.Numero_Agujeros_R
        # ----------------------------
        #  ---- Genero Cuerpo exterior
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((Numero_Agujeros_T-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((Numero_Agujeros_T-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((Numero_Agujeros_T-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  -----------------------------
        #  ---- Genero Cuerpos a restar 
        #  -----------------------------

        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)

        #  ---- Genero Cuerpo del Agujero Rasgado
               
        #  ---- Calculo desplamiento para iniciar el coliso
        Desp = obj.N_Agujeros*12.5

        Pto01 = FreeCAD.Vector(0+Desp,-3.5,0)
        Pto02 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,-3.5,0)
        Pto03 = FreeCAD.Vector(((obj.Numero_Agujeros_R-1)*12.5)+Desp,3.5,0)
        Pto04 = FreeCAD.Vector(0+Desp,3.5,0)
        #  ---- Genero puntos para circulos
        PtoC2 = FreeCAD.Vector((((obj.Numero_Agujeros_R-1)*12.5)+3.5)+Desp,0,0)
        PtoC4 = FreeCAD.Vector(-3.5+Desp,0,0)
        #  ---- Creamos lineas y arcos
        LRest1 = Part.LineSegment(Pto01,Pto02) 
        CRest2 = Part.Arc(Pto02,PtoC2,Pto03)   
        LRest3 = Part.LineSegment(Pto03,Pto04)
        CRest4 = Part.Arc(Pto04,PtoC4,Pto01)
        SRest = Part.Shape([LRest1,CRest2,LRest3,CRest4])
        WRest = Part.Wire(SRest.Edges)
        #  ---- Creo la cara con el contorno
        FRest = Part.Face(WRest)
        PRest = FRest.extrude (FreeCAD.Vector(0,0,5))
        P = P.cut (PRest)

        #  ---- Añado emplzamiento al objeto
        P.Placement = obj.Placement
        obj.Shape = P

class STR_STD_BRD_AY:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros en parte Horizontal\nMínimo 1")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Inclinado","Valores Pieza","Nº Agujeros en parte inclinada\nMínimo 1")
        obj.N_Agujeros_Inclinado = 2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 0\nMáximo = 180")
        obj.Angulo = 135
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros mayor de 2 y Angulo en 60 y 180
        if (obj.N_Agujeros_X < 1) or (obj.N_Agujeros_Inclinado < 1) or (obj.Angulo < 0) or (obj.Angulo > 180):
            if (obj.N_Agujeros_X < 1) : obj.N_Agujeros_X = 1
            if (obj.N_Agujeros_Inclinado < 1) : obj.N_Agujeros_Inclinado = 1
            if (obj.Angulo < 0) : obj.Angulo = 0
            if (obj.Angulo > 180) : obj.Angulo = 180
        
        # ----------------------------
        #  ---- Genero Cuerpo Horizontal
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector( ((obj.N_Agujeros_X-1)*12.5)+6.25,-6.25,0 )
        P3 = FreeCAD.Vector( ((obj.N_Agujeros_X-1)*12.5)+6.25,6.25,0 )
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero punto para arco
        PC2 = FreeCAD.Vector(obj.N_Agujeros_X*12.5,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        S = Part.Shape([L1,C2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,-3.25))
        # Hago los Agujeros de X
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( (x*12.5)+6.25, 0, -5), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        
        # Condicional para angulo 180 no generar cilindros
        if obj.Angulo != 180 :
            # Tengo que meter un cuarto de cilindro y unirlo a P
            # Añado condicional para que sea en funcion del angulo
            Ang = (180 - int(obj.Angulo)) / 2
            Curva = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(0, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),180)
            P = P.fuse (Curva)
        #
        #  ---- Genero Cuerpo Inclinado
        Pto1 = FreeCAD.Vector(0,-6.25,0)
        Pto2 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado-1)*12.5)+6.25,-6.25,0 )
        Pto3 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado-1)*12.5)+6.25,6.25,0 )
        Pto4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero punto para arco
        PtoC2 = FreeCAD.Vector(obj.N_Agujeros_Inclinado*12.5,0,0)
        #  ---- Creamos lineas y arcos
        LInc1 = Part.LineSegment(Pto1,Pto2) 
        CInc2 = Part.Arc(Pto2,PtoC2,Pto3)   
        LInc3 = Part.LineSegment(Pto3,Pto4)
        LInc4 = Part.LineSegment(Pto4,Pto1)
        SInc = Part.Shape([LInc1,CInc2,LInc3,LInc4])
        WInc = Part.Wire(SInc.Edges)
        #  ---- Creo la cara con el contorno
        FInc = Part.Face(WInc)
        #  ---- Le doy Volumen a la cara
        PInc = FInc.extrude (FreeCAD.Vector(0,0,3.25))
        # Hago los Agujeros en el cuerpo inclinado
        for x in range(obj.N_Agujeros_Inclinado):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( (x*12.5)+6.25, 0, -1), FreeCAD.Vector(0, 0, 1))
            PInc = PInc.cut (Agujero)
        # Condicional para angulo 180 no generar cilindros
        if obj.Angulo != 180 :
            # Curva
            #Ang = (180 - int(obj.Angulo)) / 2
            Curva = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(0, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),-Ang)
            PInc = PInc.fuse (Curva)
        # Giro en Y
        PInc.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),obj.Angulo*-1)
        
        # Junto los dos cuerpos 

        P = P.fuse(PInc)

     
        #  ---- Añado emplzamiento al objeto
        P.Placement = obj.Placement
        obj.Shape = P

class STR_STD_BRT_AZ:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros en Barra Central\nMínimo = 3")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y1","Valores Pieza","Nº Agujeros en Barra Vertical Izq\nMínimo = 1")
        obj.N_Agujeros_Y1=2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y2","Valores Pieza","Nº Agujeros en Barra Vertical Dch\nMínimo = 1")
        obj.N_Agujeros_Y2=2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 90\nMáximo = 180")
        obj.Angulo = 90

    def execute(self,obj):
        import Part,FreeCAD,FreeCADGui,math

        # Compruebo Valores
        if (obj.N_Agujeros_X < 3) or (obj.N_Agujeros_Y1 < 1)or (obj.N_Agujeros_Y2 < 1) or (obj.Angulo < 90) or (obj.Angulo > 180):
            if (obj.N_Agujeros_X < 3) : obj.N_Agujeros_X = 3
            if (obj.N_Agujeros_Y1 < 1) : obj.N_Agujeros_Y1 = 1
            if (obj.N_Agujeros_Y2 < 1) : obj.N_Agujeros_Y2 = 1
            if (obj.Angulo < 90) : obj.Angulo = 90
            if (obj.Angulo > 180) : obj.Angulo = 180
            #return
        
        # Genero Pieza en X
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_X-1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_X-1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_X-1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PX = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PX = PX.cut (Agujero)
        
        # Genero Piezas en Y1
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_Y1)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_Y1)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_Y1)*12.5)+6.25,0,0)
        PC4 = FreeCAD.Vector(-6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY1 = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_Y1+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector(x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY1 = PY1.cut (Agujero)

        PY1.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)

        P = PX.fuse (PY1)

        # Genero Piezas en Y2
        Desp = (obj.N_Agujeros_X-1)*12.5
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0+Desp,-6.25,0)
        P2 = FreeCAD.Vector(((obj.N_Agujeros_Y2)*12.5)+Desp,-6.25,0)
        P3 = FreeCAD.Vector(((obj.N_Agujeros_Y2)*12.5)+Desp,6.25,0)
        P4 = FreeCAD.Vector(0+Desp,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_Y2)*12.5)+6.25+Desp,0,0)
        PC4 = FreeCAD.Vector(-6.25+Desp,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        C4 = Part.Arc(P4,PC4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,C4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY2 = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_Y2+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector(x*12.5+Desp, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY2 = PY2.cut (Agujero)
        #  ---- giro parte Y 2 (restando de 180)----
        PY2.rotate(FreeCAD.Vector(Desp,0,0),FreeCAD.Vector(0,0,1),(180 - int(obj.Angulo)))

        P = P.fuse (PY2)

   
        P.Placement = obj.Placement
        obj.Shape = P

class STR_STD_BRT_AY:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros en parte Horizontal\nMínimo 1")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Inclinado_1","Valores Pieza","Nº Agujeros en parte inclinada Izq\nMínimo 1")
        obj.N_Agujeros_Inclinado_1 = 2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Inclinado_2","Valores Pieza","Nº Agujeros en parte inclinada Dch\nMínimo 1")
        obj.N_Agujeros_Inclinado_2 = 2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 0\nMáximo = 180")
        obj.Angulo = 135
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros mayor de 2 y Angulo en 60 y 180
        if (obj.N_Agujeros_X < 1) or (obj.N_Agujeros_Inclinado_1 < 1) or (obj.N_Agujeros_Inclinado_2 < 1) or (obj.Angulo < 0) or (obj.Angulo > 180):
            if (obj.N_Agujeros_X < 1) : obj.N_Agujeros_X = 1
            if (obj.N_Agujeros_Inclinado_1 < 1) : obj.N_Agujeros_Inclinado_1 = 1
            if (obj.N_Agujeros_Inclinado_2 < 1) : obj.N_Agujeros_Inclinado_2 = 1
            if (obj.Angulo < 0) : obj.Angulo = 0
            if (obj.Angulo > 180) : obj.Angulo = 180
        # Limito nº agujeros en Inclinadas cuando angulo es 0
        if (obj.Angulo == 0):
            if (obj.N_Agujeros_Inclinado_1 > obj.N_Agujeros_X):
                obj.N_Agujeros_Inclinado_1 = obj.N_Agujeros_X
            if (obj.N_Agujeros_Inclinado_2 > obj.N_Agujeros_X):
                obj.N_Agujeros_Inclinado_2 = obj.N_Agujeros_X


        # ----------------------------
        #  ---- Genero Cuerpo Horizontal
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector( ((obj.N_Agujeros_X)*12.5),-6.25,0 )
        P3 = FreeCAD.Vector( ((obj.N_Agujeros_X)*12.5),6.25,0 )
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        L2 = Part.LineSegment(P2,P3)
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        S = Part.Shape([L1,L2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        P = F.extrude (FreeCAD.Vector(0,0,-3.25))
        # Hago los Agujeros de X
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( (x*12.5)+6.25, 0, -5), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)

        # Condicional para angulo 180 no generar cilindros
        if obj.Angulo != 180 :
            # Tengo que meter dos cachos de cilindro en los extremos y unirlo a P
            # Añado condicional para que sea en funcion del angulo
            #  ---- Primer Cilindro
            Ang = (180 - int(obj.Angulo)) / 2
            Curva1 = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(0, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva1.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),180)
            P = P.fuse (Curva1)
            #  ---- Segundo Cilindro
            Curva2 = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(obj.N_Agujeros_X * 12.5, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva2.rotate(FreeCAD.Vector(obj.N_Agujeros_X * 12.5,0,0),FreeCAD.Vector(0,1,0),180-Ang)
            P = P.fuse (Curva2)

        #
        #  ---- Genero Cuerpo Inclinado_1 Izquierdo
        Pto1 = FreeCAD.Vector(0,-6.25,0)
        Pto2 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado_1-1)*12.5)+6.25,-6.25,0 )
        Pto3 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado_1-1)*12.5)+6.25,6.25,0 )
        Pto4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero punto para arco
        PtoC2 = FreeCAD.Vector(obj.N_Agujeros_Inclinado_1*12.5,0,0)
        #  ---- Creamos lineas y arcos
        LInc1 = Part.LineSegment(Pto1,Pto2) 
        CInc2 = Part.Arc(Pto2,PtoC2,Pto3)   
        LInc3 = Part.LineSegment(Pto3,Pto4)
        LInc4 = Part.LineSegment(Pto4,Pto1)
        SInc = Part.Shape([LInc1,CInc2,LInc3,LInc4])
        WInc = Part.Wire(SInc.Edges)
        #  ---- Creo la cara con el contorno
        FInc = Part.Face(WInc)
        #  ---- Le doy Volumen a la cara
        PInc = FInc.extrude (FreeCAD.Vector(0,0,3.25))
        # Hago los Agujeros en el cuerpo inclinado
        for x in range(obj.N_Agujeros_Inclinado_1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( (x*12.5)+6.25, 0, -1), FreeCAD.Vector(0, 0, 1))
            PInc = PInc.cut (Agujero)
        # Condicional para angulo 180 no generar cilindros
        if obj.Angulo != 180 :
            # Curva
            Curva = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(0, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),-Ang)
            PInc = PInc.fuse (Curva)
        # Giro en Y
        PInc.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,1,0),obj.Angulo*-1)
        # Junto los dos cuerpos 
        P = P.fuse(PInc)

        #  ---- Genero Cuerpo Inclinado_2 Izquierdo
        Desp = obj.N_Agujeros_X * 12.5
        Pto1 = FreeCAD.Vector(Desp,-6.25,0)
        Pto2 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado_2-1)*12.5)+6.25+Desp,-6.25,0 )
        Pto3 = FreeCAD.Vector( ((obj.N_Agujeros_Inclinado_2-1)*12.5)+6.25+Desp,6.25,0 )
        Pto4 = FreeCAD.Vector(Desp,6.25,0)
        #  ---- Genero punto para arco
        PtoC2 = FreeCAD.Vector((obj.N_Agujeros_Inclinado_2*12.5)+Desp,0,0)
        #  ---- Creamos lineas y arcos
        LInc1 = Part.LineSegment(Pto1,Pto2) 
        CInc2 = Part.Arc(Pto2,PtoC2,Pto3)   
        LInc3 = Part.LineSegment(Pto3,Pto4)
        LInc4 = Part.LineSegment(Pto4,Pto1)
        SInc = Part.Shape([LInc1,CInc2,LInc3,LInc4])
        WInc = Part.Wire(SInc.Edges)
        #  ---- Creo la cara con el contorno
        FInc = Part.Face(WInc)
        #  ---- Le doy Volumen a la cara
        PInc = FInc.extrude (FreeCAD.Vector(0,0,-3.25))
        # Hago los Agujeros en el cuerpo inclinado
        for x in range(obj.N_Agujeros_Inclinado_2):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( (x*12.5)+6.25+Desp, 0, -4), FreeCAD.Vector(0, 0, 1))
            PInc = PInc.cut (Agujero)
        # Condicional para angulo 180 no generar cilindros
        if obj.Angulo != 180 :
            # Curva
            Curva = Part.makeCylinder(3.25, 12.5, FreeCAD.Vector(Desp, -6.25, 0), FreeCAD.Vector(0, 1, 0),Ang)
            Curva.rotate(FreeCAD.Vector(Desp,0,0),FreeCAD.Vector(0,1,0),180)
            PInc = PInc.fuse (Curva)
        # Giro en Y
        PInc.rotate(FreeCAD.Vector(Desp,0,0),FreeCAD.Vector(0,1,0),(180-int(obj.Angulo))*-1)
        # Junto los dos cuerpos 
        P = P.fuse(PInc)

        #  ---- Añado emplazamiento al objeto
        P.Placement = obj.Placement
        obj.Shape = P

class STR_STD_CR:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X_Positivo","Valores Pieza","Nº Agujeros en X +\nMínimo = 1")
        obj.N_Agujeros_X_Positivo = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_X_Negativo","Valores Pieza","Nº Agujeros en X -\nMínimo = 1")
        obj.N_Agujeros_X_Negativo = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y_Positivo","Valores Pieza","Nº Agujeros en Y +\nMínimo = 1")
        obj.N_Agujeros_Y_Positivo = 2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y_Negativo","Valores Pieza","Nº Agujeros en Y -\nMínimo = 1")
        obj.N_Agujeros_Y_Negativo = 2

    def execute(self,obj):
        import Part,FreeCAD,FreeCADGui

        # Compruebo que Numero_Agujeros mayor de 2
        if (obj.N_Agujeros_X_Positivo < 1) or (obj.N_Agujeros_X_Negativo < 1) or (obj.N_Agujeros_Y_Positivo < 1) or (obj.N_Agujeros_Y_Negativo < 1):
            if (obj.N_Agujeros_X_Positivo < 1) : obj.N_Agujeros_X_Positivo = 1
            if (obj.N_Agujeros_X_Negativo < 1) : obj.N_Agujeros_X_Negativo = 1
            if (obj.N_Agujeros_Y_Positivo < 1) : obj.N_Agujeros_Y_Positivo = 1
            if (obj.N_Agujeros_Y_Negativo < 1) : obj.N_Agujeros_Y_Negativo = 1
            #return
        
        # Genero Pieza en X+
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_X_Positivo)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_X_Positivo)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_X_Positivo)*12.5)+6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PX = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_X_Positivo+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PX = PX.cut (Agujero)
        P = PX
        # Genero Pieza en X-
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_X_Negativo)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_X_Negativo)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_X_Negativo)*12.5)+6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PX = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_X_Negativo+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PX = PX.cut (Agujero)
        PX.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),180)
        P = P.fuse(PX)
        # Genero Pieza en Y+
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_Y_Positivo)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_Y_Positivo)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_Y_Positivo)*12.5)+6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_Y_Positivo+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY = PY.cut (Agujero)
        PY.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),90)
        P = P.fuse (PY)
        # Genero Pieza en Y-
        #  ---- Genero puntos de los contornos
        P1 = FreeCAD.Vector(0,-6.25,0)
        P2 = FreeCAD.Vector((obj.N_Agujeros_Y_Negativo)*12.5,-6.25,0)
        P3 = FreeCAD.Vector((obj.N_Agujeros_Y_Negativo)*12.5,6.25,0)
        P4 = FreeCAD.Vector(0,6.25,0)
        #  ---- Genero puntos para circulos
        PC2 = FreeCAD.Vector(((obj.N_Agujeros_Y_Negativo)*12.5)+6.25,0,0)
        #  ---- Creamos lineas y arcos
        L1 = Part.LineSegment(P1,P2) 
        C2 = Part.Arc(P2,PC2,P3)   
        L3 = Part.LineSegment(P3,P4)
        L4 = Part.LineSegment(P4,P1)
        #  ---- Creo el contorno
        S = Part.Shape([L1,C2,L3,L4])
        W = Part.Wire(S.Edges)
        #  ---- Creo la cara con el contorno
        F = Part.Face(W)
        #  ---- Le doy Volumen a la cara
        PY = F.extrude (FreeCAD.Vector(0,0,3.25))
        #  ---- Bucle para agujeros
        for x in range(obj.N_Agujeros_Y_Negativo+1):
            Agujero = Part.makeCylinder(3.5, 5, FreeCAD.Vector( x*12.5, 0, -1), FreeCAD.Vector(0, 0, 1))
            PY = PY.cut (Agujero)
        PY.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),270)
        P = P.fuse (PY)
     
        P.Placement = obj.Placement
        obj.Shape = P

# Vigas
class STR_ESS_BU:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros","Valores Pieza","Nº Agujeros Pieza\nMínimo = 1")
        obj.N_Agujeros = 4

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros mayor de 1
        if (obj.N_Agujeros < 1):
            obj.N_Agujeros = 1
            #return
        # Genero el cuerpo exterior
        P = Part.makeBox((obj.N_Agujeros*12.5),12.5,12.5,FreeCAD.Vector(-6.25,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        #  ---- Bucle para agujeros en X
        for x in range(obj.N_Agujeros):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        #  ---- Bucle para agujeros en Y
        for x in range(obj.N_Agujeros):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            P = P.cut (Agujero)
        #  ---- Agujeros en Z
        Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros*12.5) + 25, FreeCAD.Vector( -10, 0, 0), FreeCAD.Vector(1, 0, 0))
        P = P.cut (Agujero)
       
        P.Placement = obj.Placement
        obj.Shape = P

class STR_BEM:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros En X\nMínimo = 1")
        obj.N_Agujeros_X = 2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y","Valores Pieza","Nº Agujeros En Y\nMínimo = 1")
        obj.N_Agujeros_Y = 2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Z","Valores Pieza","Nº Agujeros En Z\nMínimo = 1")
        obj.N_Agujeros_Z = 2



    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo que Numero_Agujeros mayor de 1
        if (obj.N_Agujeros_X < 1) or (obj.N_Agujeros_Y < 1) or (obj.N_Agujeros_Z < 1):
            if (obj.N_Agujeros_X < 1) : obj.N_Agujeros_X = 1
            if (obj.N_Agujeros_Y < 1) : obj.N_Agujeros_Y = 1
            if (obj.N_Agujeros_Z < 1) : obj.N_Agujeros_Z = 1

            #return
        # Genero el cuerpo exterior
        P = Part.makeBox((obj.N_Agujeros_X*12.5),(obj.N_Agujeros_Y*12.5),(obj.N_Agujeros_Z*12.5),FreeCAD.Vector(-6.25,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        #  ---- Bucle para agujeros en X
        for x in range(obj.N_Agujeros_X):
            for y in range(obj.N_Agujeros_Y):
                Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros_Z*12.5)+20, FreeCAD.Vector( x*12.5, y*12.5, -10), FreeCAD.Vector(0, 0, 1))
                P = P.cut (Agujero)
        #  ---- Bucle para agujeros en Y
        for x in range(obj.N_Agujeros_X):
            for z in range(obj.N_Agujeros_Z):
                Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros_Y*12.5)+20, FreeCAD.Vector( x*12.5, -10, z*12.5), FreeCAD.Vector(0, 1, 0))
                P = P.cut (Agujero)
        #  ---- Agujeros en Z
        for z in range(obj.N_Agujeros_Z):
            for y in range(obj.N_Agujeros_Y):
                Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros_X*12.5)+20, FreeCAD.Vector( -10, y*12.5, z*12.5), FreeCAD.Vector(1, 0, 0))
                P = P.cut (Agujero)
       
        P.Placement = obj.Placement
        obj.Shape = P

class AGD_ESS_USH_SYM:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros Pieza_X\nMínimo = 3")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y1","Valores Pieza","Nº Agujeros en Barra Vertical Izq\nMínimo = 1")
        obj.N_Agujeros_Y1 = 2 
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y2","Valores Pieza","Nº Agujeros en Barra Vertical Dch\nMínimo = 1")
        obj.N_Agujeros_Y2 = 2

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo Valores
        if (obj.N_Agujeros_X < 3) or (obj.N_Agujeros_Y1 < 1)or (obj.N_Agujeros_Y2 < 1):
            if (obj.N_Agujeros_X < 3) : obj.N_Agujeros_X = 3
            if (obj.N_Agujeros_Y1 < 1) : obj.N_Agujeros_Y1 = 1
            if (obj.N_Agujeros_Y2 < 1) : obj.N_Agujeros_Y2 = 1

        # Genero el cuerpo exterior
        P = Part.makeBox((obj.N_Agujeros_X*12.5),12.5,12.5,FreeCAD.Vector(-6.25,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        PY1 = Part.makeBox(12.5,((obj.N_Agujeros_Y1+1)*12.5),12.5,FreeCAD.Vector(-6.25,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        PY2 = Part.makeBox(12.5,((obj.N_Agujeros_Y2+1)*12.5),12.5,FreeCAD.Vector(((obj.N_Agujeros_X-1)*12.5)-6.25,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        P = P.fuse(PY1)
        P = P.fuse(PY2)

        #  Genero los agujeros de la parte central
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        for y in range(obj.N_Agujeros_Y1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( 0, (y*12.5)+12.5, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        for y in range(obj.N_Agujeros_Y2):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( ((obj.N_Agujeros_X-1)*12.5), (y*12.5)+12.5, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)


        #  ---- Bucle para agujeros en cara Z
        for y in range(obj.N_Agujeros_X):
            if (y == 0): Longitud = (obj.N_Agujeros_Y1)*12.5
            if (y == obj.N_Agujeros_X-1): Longitud = (obj.N_Agujeros_Y2)*12.5
            if (y > 0) and (y < obj.N_Agujeros_X-1) : Longitud = 0

            Agujero = Part.makeCylinder(3.5, Longitud+20, FreeCAD.Vector( y*12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            P = P.cut (Agujero)

        #  ---- Bucle para agujeros en cara Y
        if (obj.N_Agujeros_Y1) >= (obj.N_Agujeros_Y2): 
            repeticion=(obj.N_Agujeros_Y1)
        else:
            repeticion=(obj.N_Agujeros_Y2)

        for x in range(repeticion+1):
            Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros_X*12.5) + 25, FreeCAD.Vector( -10, (x*12.5), 0), FreeCAD.Vector(1, 0, 0))
            P = P.cut (Agujero)
        
        P.Placement = obj.Placement
        obj.Shape = P

class STR_BED:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros Pieza_X\nMínimo = 2")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y","Valores Pieza","Nº Agujeros en Barra Angular\nMínimo = 1")
        obj.N_Agujeros_Y = 2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 90\nMáximo = 180")
        obj.Angulo = 135
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo Valores
        if (obj.N_Agujeros_X < 2) or (obj.N_Agujeros_Y < 1) or (obj.Angulo < 90) or (obj.Angulo > 180):
            if (obj.N_Agujeros_X < 2) : obj.N_Agujeros_X = 2
            if (obj.N_Agujeros_Y < 1) : obj.N_Agujeros_Y = 1
            if (obj.Angulo < 90) : obj.Angulo = 90
            if (obj.Angulo > 180) : obj.Angulo = 180

        # Genero el cuerpo exterior
        P = Part.makeBox(((obj.N_Agujeros_X-1)*12.5)+6.25,12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        Curva = Part.makeCylinder(6.25, 12.5, FreeCAD.Vector( 0, 0, -6.25), FreeCAD.Vector(0, 0, 1))
        P = P.fuse(Curva)
 
        #  Genero los agujeros en el cuerpo principal
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        #  ---- Bucle para agujeros en cara Z
        for x in range(obj.N_Agujeros_X-1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( (x*12.5)+12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            P = P.cut (Agujero)
        
        #  Genero cuerpo para luego girar
        PY1 = Part.makeBox(((obj.N_Agujeros_Y)*12.5)+6.25,12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        #  Genero los agujeros en el cuerpo a girar
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_Y+1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            PY1 = PY1.cut (Agujero)
        #  ---- Bucle para agujeros en cara Z
        for x in range(obj.N_Agujeros_Y):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( (x*12.5)+12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            PY1 = PY1.cut (Agujero)
        #  Giro pieza
        PY1.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)
        # Uno las dos partes
        P = P.fuse(PY1)

        #   ----- Ahora que estan girados hago los circulos centrales y los resto
        #   ----- Agujero en X
        Agujero = Part.makeCylinder(3.5,(obj.N_Agujeros_X*12.5)+((obj.N_Agujeros_Y+1)*12.5)+12.5,FreeCAD.Vector( ((obj.N_Agujeros_Y+1)*-12.5),0,0), FreeCAD.Vector(1, 0, 0))
        P=P.cut (Agujero)
        #   ----- Agujero en Inclinado
        Agujero = Part.makeCylinder(3.5,(obj.N_Agujeros_X+obj.N_Agujeros_Y+2)*12.5,FreeCAD.Vector( ((obj.N_Agujeros_X+1)*-12.5),0,0), FreeCAD.Vector(1, 0, 0))
        Agujero.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)
        #Part.show(Agujero)
        P=P.cut (Agujero)

        P.Placement = obj.Placement
        obj.Shape = P
        
class STR_BET:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros_X","Valores Pieza","Nº Agujeros en Barra Central\nMínimo = 3")
        obj.N_Agujeros_X = 3
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y1","Valores Pieza","Nº Agujeros en Barra Angular Izq\nMínimo = 1")
        obj.N_Agujeros_Y1 = 2
        obj.addProperty("App::PropertyInteger","N_Agujeros_Y2","Valores Pieza","Nº Agujeros en Barra Angular Dch\nMínimo = 1")
        obj.N_Agujeros_Y2 = 2
        obj.addProperty("App::PropertyAngle","Angulo","Valores Pieza","Ángulo\nMínimo = 90\nMáximo = 180")
        obj.Angulo = 135
        

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo Valores
        if (obj.N_Agujeros_X < 3) or (obj.N_Agujeros_Y1 < 1) or (obj.N_Agujeros_Y2 < 1) or (obj.Angulo < 90) or (obj.Angulo > 180):
            if (obj.N_Agujeros_X < 3) : obj.N_Agujeros_X = 3
            if (obj.N_Agujeros_Y1 < 1) : obj.N_Agujeros_Y1 = 1
            if (obj.N_Agujeros_Y2 < 1) : obj.N_Agujeros_Y2 = 1
            if (obj.Angulo < 90) : obj.Angulo = 90
            if (obj.Angulo > 180) : obj.Angulo = 180

        # Genero el cuerpo exterior
        P = Part.makeBox(((obj.N_Agujeros_X-1)*12.5),12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        Curva = Part.makeCylinder(6.25, 12.5, FreeCAD.Vector( 0, 0, -6.25), FreeCAD.Vector(0, 0, 1))
        P = P.fuse(Curva)
        Curva = Part.makeCylinder(6.25, 12.5,  FreeCAD.Vector( (obj.N_Agujeros_X-1)*12.5, 0, -6.25), FreeCAD.Vector(0, 0, 1))
        P = P.fuse(Curva)
 
        #  Genero los agujeros en el cuerpo principal
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_X):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            P = P.cut (Agujero)
        #  ---- Bucle para agujeros en cara Z
        for x in range(obj.N_Agujeros_X-2):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( (x*12.5)+12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            P = P.cut (Agujero)
        
        #  Genero cuerpo Izquierda
        PY1 = Part.makeBox(((obj.N_Agujeros_Y1)*12.5)+6.25,12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        #  Genero los agujeros en el cuerpo a girar
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_Y1+1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            PY1 = PY1.cut (Agujero)
        #  ---- Bucle para agujeros en cara Z
        for x in range(obj.N_Agujeros_Y1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( (x*12.5)+12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            PY1 = PY1.cut (Agujero)
        #  Giro pieza
        PY1.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)
        # Uno las dos partes
        P = P.fuse(PY1)
        #  Genero cuerpo Derecha
        PY2 = Part.makeBox(((obj.N_Agujeros_Y2)*12.5)+6.25,12.5,12.5,FreeCAD.Vector((obj.N_Agujeros_X-1)*12.5,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        #  Genero los agujeros en el cuerpo a girar
        #  ---- Bucle para agujeros en cara X
        for x in range(obj.N_Agujeros_Y2+1):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( ((obj.N_Agujeros_X-1)*12.5)+x*12.5, 0, -10), FreeCAD.Vector(0, 0, 1))
            PY2 = PY2.cut (Agujero)
        #  ---- Bucle para agujeros en cara Z
        for x in range(obj.N_Agujeros_Y2):
            Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( ((obj.N_Agujeros_X-1)*12.5)+(x*12.5)+12.5, -10, 0), FreeCAD.Vector(0, 1, 0))
            PY2 = PY2.cut (Agujero)
        #  Giro pieza
        PY2.rotate(FreeCAD.Vector(((obj.N_Agujeros_X-1)*12.5),0,0),FreeCAD.Vector(0,0,1),180-int(obj.Angulo))
        # Uno las dos partes
        P = P.fuse(PY2)

        #   ----- Ahora que estan girados, hago los circulos centrales y los resto
        #   ----- Agujero en X
        Agujero = Part.makeCylinder(3.5,(obj.N_Agujeros_X+obj.N_Agujeros_Y1+obj.N_Agujeros_Y2+2)*12.5,FreeCAD.Vector(((obj.N_Agujeros_Y1+1)*-12.5),0,0), FreeCAD.Vector(1, 0, 0))
        P=P.cut (Agujero)
        #   ----- Agujero en Inclinado Y1
        Agujero = Part.makeCylinder(3.5,(obj.N_Agujeros_X+obj.N_Agujeros_Y1+2)*12.5,FreeCAD.Vector( ((obj.N_Agujeros_X+1)*-12.5),0,0), FreeCAD.Vector(1, 0, 0))
        Agujero.rotate(FreeCAD.Vector(0,0,0),FreeCAD.Vector(0,0,1),obj.Angulo)
        P=P.cut (Agujero)
        #   ----- Agujero en Inclinado Y2
        Agujero = Part.makeCylinder(3.5,(obj.N_Agujeros_X+obj.N_Agujeros_Y2+2)*12.5,FreeCAD.Vector(0,0,0), FreeCAD.Vector(1, 0, 0))
        Agujero.rotate(FreeCAD.Vector(((obj.N_Agujeros_X-1)*12.5),0,0),FreeCAD.Vector(0,0,1),180-int(obj.Angulo))
        P=P.cut (Agujero)

        P.Placement = obj.Placement
        obj.Shape = P
 
class STR_BXS_ESS_H:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros","Valores Pieza","Nº Agujeros \nMínimo = 1")
        obj.N_Agujeros = 1
     

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo Valores
        if (obj.N_Agujeros < 1): obj.N_Agujeros = 1

        # Genero el cuerpo exterior
        P = Part.makeBox(obj.N_Agujeros*12.5,12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        
        #  Genero los cuerpos para restar del cuerpo exterior
        #  ---- Cubo central
        Cubo = Part.makeBox(((obj.N_Agujeros-1)*12.5)+6.25,9.375,20,FreeCAD.Vector(3.125,-4.6875,-10),FreeCAD.Vector(0,0,1))
        P = P.cut (Cubo)
        #  ---- Agujero
        Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros*12.5)+20, FreeCAD.Vector( -10, 0, 0), FreeCAD.Vector(1, 0, 0))
        P = P.cut (Agujero)
        
        P.Placement = obj.Placement
        obj.Shape = P
 
class STR_BXS_ESS_C:

    def __init__(self,obj):
        obj.Proxy = self
        obj.addProperty("App::PropertyInteger","N_Agujeros","Valores Pieza","Nº Agujeros \nMínimo = 3")
        obj.N_Agujeros = 3
     

    def execute(self,obj):
        import Part,FreeCAD

        # Compruebo Valores
        if (obj.N_Agujeros < 3): obj.N_Agujeros = 3

        # Genero el cuerpo exterior
        P = Part.makeBox(obj.N_Agujeros*12.5,12.5,12.5,FreeCAD.Vector(0,-6.25,-6.25),FreeCAD.Vector(0,0,1))
        
        #  Genero los cuerpos para restar del cuerpo exterior
        #  ---- Cubo central
        Cubo = Part.makeBox(((obj.N_Agujeros-2)*12.5),9.375,20,FreeCAD.Vector(12.5,-4.6875,-10),FreeCAD.Vector(0,0,1))
        P = P.cut (Cubo)
        #  ---- Agujero Longitudinal
        Agujero = Part.makeCylinder(3.5, (obj.N_Agujeros*12.5)+20, FreeCAD.Vector( -10, 0, 0), FreeCAD.Vector(1, 0, 0))
        P = P.cut (Agujero)
        #  ---- Agujero Cubo Inicio cara X
        Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( 6.25, -10, 0), FreeCAD.Vector(0, 1, 0))
        P = P.cut (Agujero)
        #  ---- Agujero Cubo Final cara X
        Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector(((obj.N_Agujeros-1)*12.5)+6.25, -10, 0), FreeCAD.Vector(0, 1, 0))
        P = P.cut (Agujero)
        #  ---- Agujero Cubo Inicio cara Z
        Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector( 6.25, 0, -10), FreeCAD.Vector(0, 0, 1))
        P = P.cut (Agujero)
        #  ---- Agujero Cubo Final cara Z
        Agujero = Part.makeCylinder(3.5, 20, FreeCAD.Vector(((obj.N_Agujeros-1)*12.5)+6.25, 0, -10), FreeCAD.Vector(0, 0, 1))
        P = P.cut (Agujero)
        
        P.Placement = obj.Placement
        obj.Shape = P
 
