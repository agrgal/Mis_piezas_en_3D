# -*- coding: utf-8 -*-
import FreeCAD

def ListadoPiezas():
  FreeCAD.Console.PrintMessage("Esto se ejecuta\n")
  # List all objects of the document
  objs = FreeCAD.ActiveDocument.Objects

  piezas = {}

  for obj in objs:
      name = obj.Name                                             # list the Name  of the object  (not modifiable)
      #b = obj.Label                                            # list the Label of the object  (modifiable)
      try:
          c = str(obj.Codigo)     
          FreeCAD.Console.PrintMessage("c: "+c + "\n")                               # list the LabeText of the text (modifiable)
          prePieza = {}
          if c in piezas:
            prePieza = piezas[c]
            
          # FreeCAD.Console.PrintMessage("properties: "+str(dir(obj)) + "\n")
          # FreeCAD.Console.PrintMessage("properties ViewObject: "+str(dir(obj.ViewObject)) + "\n")
          color = str(obj.ViewObject.ShapeColor)
          # FreeCAD.Console.PrintMessage("color: "+str(color) + "\n")
          preColor = []
          if color in prePieza:
            preColor = prePieza[color]
          preColor.append(name)
          
          prePieza[color] = preColor
          piezas[c] = prePieza

          # FreeCAD.Console.PrintMessage(str(a) +" - "+  str(c) + "\n") # Displays the Name the Label and the text
      except ValueError:
          FreeCAD.Console.PrintMessage(ValueError + "\n") # Displays the Name and the Label of the object
  import json
  FreeCAD.Console.PrintMessage(json.dumps(piezas) + "\n")

  #Vamos a printear lo que luego necesitas, el número de piezas diferentes y por cada pieza el número de colores diferentes y por cada color las piezas
  
  FreeCAD.Console.PrintMessage("\nRESUMEN:\n")
  codes = piezas.keys()
  FreeCAD.Console.PrintMessage("Hay " + str(len(codes)) + " típos de piezas diferentes:\n")
  FreeCAD.Console.PrintMessage(str(codes) + "\n")
  for code in codes:
    colorsDic = piezas[code]
    colors = colorsDic.keys()
    FreeCAD.Console.PrintMessage("\tDel código -" + code + "- hay " + str(len(colors)) + " colores diferentes:\n")
    FreeCAD.Console.PrintMessage("\t" + str(colors) + "\n")
    for color in colors:
      names = colorsDic[color]
      FreeCAD.Console.PrintMessage("\t\tDel color -" + color + "- hay " + str(len(names)) + " piezas diferentes:\n")
      FreeCAD.Console.PrintMessage("\t\t" + str(names) + "\n")



  return

